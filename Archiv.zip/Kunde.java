
public abstract class Kunde {
	private Konto konto;

}
