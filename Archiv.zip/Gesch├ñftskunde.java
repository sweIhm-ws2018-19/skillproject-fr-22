
public class Geschäftskunde extends Kunde {
	private String firmenname;
	private Adresse domizilAdresse;
}
