public class Konto {
	private String bezeichnung;
	private Kunde zeichnungsberechtigter;
	
	public double saldo() {
		return Geldbetrag;
	}
	public void einzahlen(double eingehenderBetrag, double Geldbetrag) {
		
	}
}
