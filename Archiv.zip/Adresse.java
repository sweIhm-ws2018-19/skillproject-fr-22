
public class Adresse {
	private String strasse;
	private int hausnummer;
	private String plz;
	private String ort;
	
}
